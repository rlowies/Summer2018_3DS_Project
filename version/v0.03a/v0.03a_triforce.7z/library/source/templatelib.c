int myLibFunction() {

	
	return 42;

}
